import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

;public class TopFiveDestinationList {


    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	TopDestinationListFrame topDestinationListFrame = new TopDestinationListFrame();
                topDestinationListFrame.setTitle("Top 5 Destination List");
                topDestinationListFrame.setVisible(true);
 
	  
  
                JPanel panel = new JPanel();
                // Add new button stating Click me
                JButton button = new JButton("Click me");
                // Add new label stating name
               
                JLabel label = new JLabel("Chloe Ninefeldt");
                // Change color on South Border to let label stick out more
                panel.setBackground(Color.YELLOW);
                panel.add(label);
                panel.add(button);
                topDestinationListFrame.getContentPane().add(panel, BorderLayout.SOUTH);
               
            
                
                
            }
        });
    }
}





class TopDestinationListFrame extends JFrame {
    private DefaultListModel listModel;

    public TopDestinationListFrame() {
        super("Top Five Destination List");

       
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(900, 750);
        
        
        

        listModel = new DefaultListModel();
        
        
        //Make updates to your top 5 list below. Import the new image files to resources directory.
        addDestinationNameAndPicture("1. Visit Minneaoplis, Minnesota and see the beautiful skyline and tour the Mall of America.--" + "Photo: https://commons.wikimedia.org/wiki/Category:Aerial_photographs_of_Minneapolis#/media/File:2009-0603-05-Air-MPLS.jpg", new ImageIcon(getClass().getResource("/resources/Minnesota.jpg")));
        addDestinationNameAndPicture("2. Visit Austin, TX and enjoy good BBQ and see the Capital State building.--" + "Photo: https://commons.wikimedia.org/wiki/Austin,_Texas#/media/File:Texas_State_Capitol_building-close_oblique_view.JPG", new ImageIcon(getClass().getResource("/resources/Austin.jpg")));
        addDestinationNameAndPicture("3. Visit San Diego, CA and enjoy the city building lights at night and sandy beaches.--" + "Photo: https://commons.wikimedia.org/wiki/San_Diego,_California#/media/File:San_Diego_Reflecting_Pond.jpg", new ImageIcon(getClass().getResource("/resources/SanDiego.jpg")));
        addDestinationNameAndPicture("4. Visit Chicago, IL to enjoy deepdish pizza and explore the city.--" + "Photo: https://commons.wikimedia.org/wiki/Chicago#/media/File:The-place-1.jpg", new ImageIcon(getClass().getResource("/resources/Chicago.jpg")));
        addDestinationNameAndPicture("5. Visit Manhattan, New York and watch live performances, view beautiful art, and more.--" + "Photo: https://commons.wikimedia.org/wiki/New_York_City#/media/File:Manhattan3_amk.jpg", new ImageIcon(getClass().getResource("/resources/ManhattanNY.jpg")));
        
        JList list = new JList(listModel);
        JScrollPane scrollPane = new JScrollPane(list);

        TextAndIconListCellRenderer renderer = new TextAndIconListCellRenderer(2);
        list.setBackground(Color.LIGHT_GRAY);
        list.setSelectionBackground(Color.orange);
        list.setCellRenderer(renderer);
       

        getContentPane().add(scrollPane, BorderLayout.CENTER);
       
       
        
      
        
      
     
    }
    

    private void addDestinationNameAndPicture(String text, Icon icon) {
        TextAndIcon tai = new TextAndIcon(text, icon);
        listModel.addElement(tai);
    }
}


class TextAndIcon {
    private String text;
    private Icon icon;

    public TextAndIcon(String text, Icon icon) {
        this.text = text;
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    }
}


class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer {
    private static final Border NO_FOCUS_BORDER = new EmptyBorder(1, 1, 1, 1);

    private Border insideBorder;

    public TextAndIconListCellRenderer() {
        this(0, 0, 0, 0);
    }

    public TextAndIconListCellRenderer(int padding) {
        this(padding, padding, padding, padding);
    }

    public TextAndIconListCellRenderer(int topPadding, int rightPadding, int bottomPadding, int leftPadding) {
        insideBorder = BorderFactory.createEmptyBorder(topPadding, leftPadding, bottomPadding, rightPadding);
        setOpaque(true);
    }

    public Component getListCellRendererComponent(JList list, Object value,
    int index, boolean isSelected, boolean hasFocus) {
        // The object from the combo box model MUST be a TextAndIcon.
        TextAndIcon tai = (TextAndIcon) value;

        // Sets text and icon on 'this' JLabel.
        setText(tai.getText());
        setIcon(tai.getIcon());

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        Border outsideBorder;

        if (hasFocus) {
            outsideBorder = UIManager.getBorder("List.focusCellHighlightBorder");
        } else {
            outsideBorder = NO_FOCUS_BORDER;
        }

        setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));
        setComponentOrientation(list.getComponentOrientation());
        setEnabled(list.isEnabled());
        setFont(list.getFont());
        
       

        return this;
    }

    // The following methods are overridden to be empty for performance
    // reasons. If you want to understand better why, please read:
    //
    // http://java.sun.com/javase/6/docs/api/javax/swing/DefaultListCellRenderer.html#override

    public void validate() {}
    public void invalidate() {}
    public void repaint() {}
    public void revalidate() {}
    public void repaint(long tm, int x, int y, int width, int height) {}
    public void repaint(Rectangle r) {}
}